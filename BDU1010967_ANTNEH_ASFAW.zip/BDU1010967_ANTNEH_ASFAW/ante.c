#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main (){
    
    printf("\n      ");
    printf("-------------------------------------------------------\n");
    printf("      -------------------------------------------------------\n");
    printf("\n	                  SYSTEM PROGRAMMING");
     printf("\n	                    ANTENEHE ASFAW\n");
     
    printf("\n\n      ");
    printf("-------------------------------------------------------\n");
    printf("      -------------------------------------------------------\n\n");
    
    printf("		PRESS ENTER KEY TO CONTINUE : ");
    getchar();
	system("PING.bat");
}
